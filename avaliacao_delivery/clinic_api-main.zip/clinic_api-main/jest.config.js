export default {
    testEnvironment: "node"
}