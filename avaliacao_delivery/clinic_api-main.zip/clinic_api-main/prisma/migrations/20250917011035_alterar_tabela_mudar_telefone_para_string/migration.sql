-- AlterTable
ALTER TABLE "public"."paciente" ALTER COLUMN "telefone" SET DATA TYPE TEXT;
