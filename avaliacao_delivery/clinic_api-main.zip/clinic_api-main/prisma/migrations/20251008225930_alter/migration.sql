-- AlterTable
ALTER TABLE "public"."prontuario" ALTER COLUMN "data" DROP NOT NULL;
